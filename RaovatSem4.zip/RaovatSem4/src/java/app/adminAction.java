/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

import com.opensymphony.xwork2.ActionSupport;
import entity.raovat;
import java.util.ArrayList;
import model.DataProcess;

/**
 *
 * @author VUXUANQUYEN
 */
public class adminAction extends ActionSupport {
    
    public adminAction() {
    }
       private ArrayList<raovat> items;
       private ArrayList<raovat> list;
       private String idtin;

    public ArrayList<raovat> getItems() {
        return items;
    }

    public void setItems(ArrayList<raovat> items) {
        this.items = items;
    }

    public ArrayList<raovat> getList() {
        return list;
    }

    public void setList(ArrayList<raovat> list) {
        this.list = list;
    }

    public String getIdtin() {
        return idtin;
    }

    public void setIdtin(String idtin) {
        this.idtin = idtin;
    }
       
        public String admin()throws Exception{
        DataProcess db=new DataProcess();
        items=db.getDataadmin();
        return "success";
    }
    public String duyettin()throws Exception
    {
        DataProcess db=new DataProcess();
        list=db.update(idtin);
        return "success";
    }
    public String execute() throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
