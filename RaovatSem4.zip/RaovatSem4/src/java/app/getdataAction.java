/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

import com.opensymphony.xwork2.ActionSupport;
import entity.raovat;
import java.util.ArrayList;
import model.DataProcess;

/**
 *
 * @author VUXUANQUYEN
 */
public class getdataAction extends ActionSupport {

    public getdataAction() {
    }
    private ArrayList<raovat> listall;
    private ArrayList<raovat> items;
    private ArrayList<raovat> list;
    private ArrayList<raovat> listacc;
    private ArrayList<raovat> listid;
    private ArrayList<raovat> listsearch;
    private String idtin;
    private String idacc;
    private String songay;
    private int amount;
    private String sort;
    private String key;

    public ArrayList<raovat> getList() {
        return list;
    }

    public void setList(ArrayList<raovat> list) {
        this.list = list;
    }

    public String getIdtin() {
        return idtin;
    }

    public void setIdtin(String idtin) {
        this.idtin = idtin;
    }

    public String getIdacc() {
        return idacc;
    }

    public void setIdacc(String idacc) {
        this.idacc = idacc;
    }

    public ArrayList<raovat> getListall() {
        return listall;
    }

    public void setListall(ArrayList<raovat> listall) {
        this.listall = listall;
    }

    public ArrayList<raovat> getItems() {
        return items;
    }

    public void setItems(ArrayList<raovat> items) {
        this.items = items;
    }

    public ArrayList<raovat> getListacc() {
        return listacc;
    }

    public void setListacc(ArrayList<raovat> listacc) {
        this.listacc = listacc;
    }

    public ArrayList<raovat> getListid() {
        return listid;
    }

    public void setListid(ArrayList<raovat> listid) {
        this.listid = listid;
    }

    public ArrayList<raovat> getListsearch() {
        return listsearch;
    }

    public void setListsearch(ArrayList<raovat> listsearch) {
        this.listsearch = listsearch;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public String getSongay() {
        return songay;
    }

    public void setSongay(String songay) {
        this.songay = songay;
    }

    public String getAll() throws Exception {
        DataProcess db = new DataProcess();
        //listall=db.getData();     
        if (sort == null) {
            listall = db.getData();
        }
        if (sort != null && sort.equals("giathaptruoc")) {
            listall = db.getdataPrice1();
        }
        if (sort != null && sort.equals("giacaotruoc")) {
            listall = db.getdataPrice2();
        }
        if (sort != null && sort.equals("tinmoitruoc")) {
            listall = db.gettinmoi();
        }
        if (sort != null && sort.equals("tincutruoc")) {
            listall = db.gettincu();
        }
        if (sort != null && sort.equals("tinhtrangmoi")) {
            listall = db.getmoi();
        }
         if (sort != null && sort.equals("tinhtrangcu")) {
            listall = db.getcu();
        }
        return "success";
    }

    public String getAlloff() throws Exception {
        DataProcess db = new DataProcess();
        items = db.getDataadmin();
        return "success";
    }

    public String duyettin() throws Exception {
        DataProcess db = new DataProcess();
        list = db.update(idtin);
        return "success";
    }

    public String getlistacc() throws Exception {
        DataProcess db = new DataProcess();
        listacc = db.getListaccount(idacc);
        return "success";
    }

    public String updateacc() throws Exception {
        DataProcess db = new DataProcess();
        db.updateacc(idacc, amount,Integer.parseInt(songay));
        return "success";
    }

    public String getbyid() throws Exception {
        DataProcess db = new DataProcess();
        listid = db.getbyId(idtin);
        return "success";
    }
    public String search() throws Exception
    {
        DataProcess db=new DataProcess();
        listsearch=db.Search(key);
        return "success";
    }
    public String execute() throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
