/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

import com.opensymphony.xwork2.ActionSupport;
import entity.user;
import java.util.Map;
import javax.servlet.http.HttpSession;
import model.DataProcess;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.SessionAware;

/**
 *
 * @author VUXUANQUYEN
 */
public class loginAction extends ActionSupport  implements SessionAware {
    
     //session
    private static final long serialVersionUID = -3434561352924343132L;
    private SessionMap<String, Object> sessionMap;

    public void setSession(Map<String, Object> map) {
        sessionMap = (SessionMap<String, Object>) map;
    }
    //login
    private String emailid;
    private String pass;
    private String noti;

    public String getEmailid() {
        return emailid;
    }

    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getNoti() {
        return noti;
    }

    public void setNoti(String noti) {
        this.noti = noti;
    }
    
    
    
    
    public loginAction() {
    }
    
    public String execute() throws Exception {
         HttpSession session = ServletActionContext.getRequest().getSession(true);
         DataProcess db=new DataProcess();
         user loguser=db.checkLogin(emailid, pass);
         if(loguser!=null)
         {
             //add user session
             sessionMap.put("loguser", loguser);
             
             return "success";
         }
         return "failed";
    }
    
}
