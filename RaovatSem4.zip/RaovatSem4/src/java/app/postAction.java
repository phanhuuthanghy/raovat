/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

import com.opensymphony.xwork2.ActionSupport;
import java.io.File;
import javax.servlet.http.HttpServletRequest;
import model.DataProcess;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.interceptor.ServletRequestAware;

/**
 *
 * @author VUXUANQUYEN
 */
public class postAction extends ActionSupport  implements ServletRequestAware {

    private File userImage;
    private String userImageContentType;
    private static String userImageFileName;
    private HttpServletRequest servletRequest;

    public postAction() {
    }

    public String execute() throws Exception {
       try {
            File fileToCreate = new File("C:\\Users\\boylo\\Documents\\NetBeansProjects\\Projectsem4\\RaovatSem4\\web\\upload", this.userImageFileName);

            FileUtils.copyFile(this.userImage, fileToCreate);
            DataProcess db=new DataProcess();
            db.Posttin(idacc,"dt1","DN",kieutin,tieude,userImageFileName,tinhtrang,gia,mota,name,email,sdt,diachi,type);
          
            
        } catch (Exception e) {
            e.printStackTrace();
            addActionError(e.getMessage());

            return INPUT;
        }
        return SUCCESS;
    }
     @Override
    public void setServletRequest(HttpServletRequest servletRequest) {
        this.servletRequest = servletRequest;
    }

     public File getUserImage() {
        return userImage;
    }

    public void setUserImage(File userImage) {
        this.userImage = userImage;
    }

    public String getUserImageContentType() {
        return userImageContentType;
    }

    public void setUserImageContentType(String userImageContentType) {
        this.userImageContentType = userImageContentType;
    }

    public String getUserImageFileName() {
        return userImageFileName;
    }

    public void setUserImageFileName(String userImageFileName) {
        this.userImageFileName = userImageFileName;
    }
    private String idacc;
    private String kieutin;
    private String tieude;
    private String tinhtrang;
    private String gia;
    private String mota;
    private String name;
    private String email;
    private String sdt;
    private String diachi;
    private String type;

    public String getKieutin() {
        return kieutin;
    }

    public void setKieutin(String kieutin) {
        this.kieutin = kieutin;
    }

    public String getTieude() {
        return tieude;
    }

    public void setTieude(String tieude) {
        this.tieude = tieude;
    }

    

    public String getTinhtrang() {
        return tinhtrang;
    }

    public void setTinhtrang(String tinhtrang) {
        this.tinhtrang = tinhtrang;
    }

    public String getGia() {
        return gia;
    }

    public void setGia(String gia) {
        this.gia = gia;
    }

    public String getMota() {
        return mota;
    }

    public void setMota(String mota) {
        this.mota = mota;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getDiachi() {
        return diachi;
    }

    public void setDiachi(String diachi) {
        this.diachi = diachi;
    }

    public String getIdacc() {
        return idacc;
    }

    public void setIdacc(String idacc) {
        this.idacc = idacc;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    
}
