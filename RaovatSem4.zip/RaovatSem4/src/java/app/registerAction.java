/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

import com.opensymphony.xwork2.ActionSupport;
import model.DataProcess;

/**
 *
 * @author VUXUANQUYEN
 */
public class registerAction extends ActionSupport {
    
    private String emailid;
    private String pass;
    private String hoten;

    public String getEmailid() {
        return emailid;
    }

    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }
    
    
    
    public registerAction() {
    }
    
    public String execute() throws Exception {
        DataProcess db=new DataProcess();
       if(db.Register(emailid, pass, hoten)!=false)
       {
           return "success";
       }
       return "failed";
    }
    
}
