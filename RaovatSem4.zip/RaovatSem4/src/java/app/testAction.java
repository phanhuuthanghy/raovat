/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

import com.opensymphony.xwork2.ActionSupport;
import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;

/**
 *
 * @author VUXUANQUYEN
 */
public class testAction extends ActionSupport {

    public testAction() {
    }

    public String execute() throws Exception {
       for(int i=0;i<userImage.length;i++)
       {
           File img=userImage[i];
           String fileimg=userImageFileName[i];
           File destFile=new File(saveDirectory +File.separator +fileimg);
           try
           {
           FileUtils.copyFile(img, destFile);
           }catch(IOException ex)
                   {
                   ex.printStackTrace();
                    return INPUT;
                   }
          
       }
       return SUCCESS;
    }
    private File[] userImage;
    private String[] userImageContentType;
    private static String[] userImageFileName;
    private String saveDirectory;
    public File[] getUserImage() {
        return userImage;
    }

    public void setUserImage(File[] userImage) {
        this.userImage = userImage;
    }

    public String[] getUserImageContentType() {
        return userImageContentType;
    }

    public void setUserImageContentType(String[] userImageContentType) {
        this.userImageContentType = userImageContentType;
    }

    public static String[] getUserImageFileName() {
        return userImageFileName;
    }

    public static void setUserImageFileName(String[] userImageFileName) {
        testAction.userImageFileName = userImageFileName;
    }

    public String getSaveDirectory() {
        return saveDirectory;
    }

    public void setSaveDirectory(String saveDirectory) {
        this.saveDirectory = saveDirectory;
    }
    

}
