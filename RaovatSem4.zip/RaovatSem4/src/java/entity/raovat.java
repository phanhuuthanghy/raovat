/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author VUXUANQUYEN
 */
public class raovat {
  private String idtin;
  private String nameacc;
  private String diachi;
  private String kieutin;
  private String tieude;
  private String img;
  private String gia;
  private String namedanhmuc;
  private String thoigian;
  private String std;
  private String mota;
  private String tinhtrang;
  private String diachicuthe;

    public raovat(String idtin, String nameacc, String diachi, String kieutin, String tieude, String img, String gia, String namedanhmuc, String thoigian, String std, String mota, String tinhtrang, String diachicuthe) {
        this.idtin = idtin;
        this.nameacc = nameacc;
        this.diachi = diachi;
        this.kieutin = kieutin;
        this.tieude = tieude;
        this.img = img;
        this.gia = gia;
        this.namedanhmuc = namedanhmuc;
        this.thoigian = thoigian;
        this.std = std;
        this.mota = mota;
        this.tinhtrang = tinhtrang;
        this.diachicuthe = diachicuthe;
    }
  
   

   

    public String getStd() {
        return std;
    }

    public void setStd(String std) {
        this.std = std;
    }

    public String getMota() {
        return mota;
    }

    public void setMota(String mota) {
        this.mota = mota;
    }
  

    public String getIdtin() {
        return idtin;
    }

    public void setIdtin(String idtin) {
        this.idtin = idtin;
    }

    public String getNameacc() {
        return nameacc;
    }

    public void setNameacc(String nameacc) {
        this.nameacc = nameacc;
    }

    public String getDiachi() {
        return diachi;
    }

    public void setDiachi(String diachi) {
        this.diachi = diachi;
    }

    public String getKieutin() {
        return kieutin;
    }

    public void setKieutin(String kieutin) {
        this.kieutin = kieutin;
    }

    public String getTieude() {
        return tieude;
    }

    public void setTieude(String tieude) {
        this.tieude = tieude;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getGia() {
        return gia;
    }

    public void setGia(String gia) {
        this.gia = gia;
    }

    public String getNamedanhmuc() {
        return namedanhmuc;
    }

    public void setNamedanhmuc(String namedanhmuc) {
        this.namedanhmuc = namedanhmuc;
    }

    public String getThoigian() {
        return thoigian;
    }

    public void setThoigian(String thoigian) {
        this.thoigian = thoigian;
    }

    public String getTinhtrang() {
        return tinhtrang;
    }

    public void setTinhtrang(String tinhtrang) {
        this.tinhtrang = tinhtrang;
    }

    public String getDiachicuthe() {
        return diachicuthe;
    }

    public void setDiachicuthe(String diachicuthe) {
        this.diachicuthe = diachicuthe;
    }

  
  
}
