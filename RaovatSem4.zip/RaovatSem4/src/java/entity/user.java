/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author VUXUANQUYEN
 */
public class user {
    private String iduser;
    private String email;
    private String pass;
    private String img;
    private String name;
    private int sotien;
    private String std;
    private String ngaygiahan;
    private String ngayhethan;
   
    private String type;

    public String getIduser() {
        return iduser;
    }

    public void setIduser(String iduser) {
        this.iduser = iduser;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSotien() {
        return sotien;
    }

    public void setSotien(int sotien) {
        this.sotien = sotien;
    }

    public String getNgaygiahan() {
        return ngaygiahan;
    }

    public void setNgaygiahan(String ngaygiahan) {
        this.ngaygiahan = ngaygiahan;
    }

    public String getNgayhethan() {
        return ngayhethan;
    }

    public void setNgayhethan(String ngayhethan) {
        this.ngayhethan = ngayhethan;
    }

   

    public String getStd() {
        return std;
    }

    public void setStd(String std) {
        this.std = std;
    }

    public user() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    
   
    
}
