/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entity.raovat;
import entity.user;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author VUXUANQUYEN
 */
public class DataProcess {

    public Connection getConnection() {
        Connection conn = null;
        try {
            //com.microsoft.sqlserver.jdbc.SQLServerDriver
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String user = "sa";
            String pass = "123456";
            String URL = "jdbc:sqlserver://127.0.0.1:1433;databaseName=Raovat";
            try {
                conn = DriverManager.getConnection(URL, user, pass);
            } catch (SQLException ex) {
                Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);
        }
        return conn;
    }

    public user checkLogin(String email, String pass) {
        user acc = null;
        String sql = "SELECT * FROM tblaccount WHERE _email=? and _pass=?";

        try {
            PreparedStatement prst = getConnection().prepareStatement(sql);
            prst.setString(1, email);
            prst.setString(2, pass);
            ResultSet rs = prst.executeQuery();
            while (rs.next()) {
                acc = new user();
                acc.setEmail(email);
                acc.setPass(pass);
                acc.setName(rs.getString(4));
                acc.setIduser(rs.getString(1));
                acc.setSotien(rs.getInt(8));
                acc.setStd(rs.getString(7));
                acc.setType(rs.getString(6));
                acc.setNgayhethan(rs.getString(10));
            }
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);
        }
        return acc;
    }

    public boolean Register(String email, String pass, String name) {
        String sql = " INSERT INTO tblaccount(_email,_pass,_hoten) VALUES(?,?,?)";
        int result = 0;
        try {
            PreparedStatement prst = getConnection().prepareStatement(sql);
            prst.setString(1, email);
            prst.setString(2, pass);
            prst.setString(3, name);
            result = prst.executeUpdate();
            //result=rs.next();
            //rs.close(); 
            prst.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result > 0;
    }

    public boolean Posttin(String idacc, String iddanhmuc, String iddiachi, String kieutin,
            String tieude, String img, String tinhtrang, String gia, String mota,
            String name, String email, String std, String diachi, String type) {
        String sql = " INSERT INTO tbltinraovat values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        int result = 0;
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        try {
            PreparedStatement prst = getConnection().prepareStatement(sql);
            prst.setString(1, idacc);
            prst.setString(2, iddanhmuc);
            prst.setString(3, iddiachi);
            prst.setString(4, kieutin);
            prst.setString(5, tieude);
            prst.setString(6, img);
            prst.setString(7, tinhtrang);
            prst.setString(8, gia);
            prst.setString(9, mota);
            prst.setString(10, name);
            prst.setString(11, email);
            prst.setString(12, std);
            prst.setString(13, diachi);
            prst.setString(14, dateFormat.format(cal.getTime()));
            prst.setString(15, type);
            prst.setString(16, "off");
            result = prst.executeUpdate();
            //result=rs.next();
            //rs.close(); 
            prst.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result > 0;
    }

    public ArrayList<raovat> getData() {
        ArrayList<raovat> list = new ArrayList<raovat>();
        String sql = "select tbltinraovat._idtin,tbltinraovat._iddanhmuc_fk,tbltinraovat._iddiachi_fk,tbltinraovat._idaccount_fk,tbltinraovat._kieutin,tbltinraovat._tieude,tbltinraovat._img,\n"
                + "       tbltinraovat._gia,tbltinraovat._thoigian,tbltinraovat._type,tbltinraovat._std,tbltinraovat._mota,\n"
                + "	   tblaccount._idaccount,tblaccount._hoten,\n"
                + "	   tbldanhmuc._iddanhmuc,tbldanhmuc._tendanhmuc,\n"
                + "	   tbldiachi._iddiachi,tbldiachi._tendiachi,tbltinraovat._tinhtrang,tbltinraovat._diachi \n"
                + "from tbltinraovat inner join tblaccount on tbltinraovat._idaccount_fk=tblaccount._idaccount\n"
                + "                  inner join tbldanhmuc on tbltinraovat._iddanhmuc_fk=tbldanhmuc._iddanhmuc\n"
                + "				  inner join tbldiachi on tbltinraovat._iddiachi_fk=tbldiachi._iddiachi\n"
                + "				  where getdate()- tbltinraovat._thoigian<30 and tbltinraovat._status='on' ORDER BY tbltinraovat._type desc ,tbltinraovat._thoigian desc";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String idtin = rs.getString(1);
                String nameacc = rs.getString(14);
                String namediachi = rs.getString(18);
                String kieutin = rs.getString(5);
                String tieude = rs.getString(6);
                String img = rs.getString(7);
                String gia = rs.getString(8);
                String thoigian = rs.getString(9);
                String namedanhmuc = rs.getString(16);
                String std = rs.getString(11);
                String mota = rs.getString(12);
                String tinhtrang = rs.getString(19);
                String diachicuthe = rs.getString(20);
                raovat temp = new raovat(idtin, nameacc, namediachi, kieutin, tieude, img, gia, namedanhmuc, thoigian, std, mota, tinhtrang, diachicuthe);
                list.add(temp);
            }
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);

        }
        return list;
    }

    public ArrayList<raovat> getDataadmin() {
        ArrayList<raovat> list = new ArrayList<raovat>();
        String sql = " select tbltinraovat._idtin,tbltinraovat._iddanhmuc_fk,tbltinraovat._iddiachi_fk,tbltinraovat._idaccount_fk,tbltinraovat._kieutin,tbltinraovat._tieude,tbltinraovat._img,\n"
                + "       tbltinraovat._gia,tbltinraovat._thoigian,tbltinraovat._type,tbltinraovat._std,tbltinraovat._mota,\n"
                + "	   tblaccount._idaccount,tblaccount._hoten,\n"
                + "	   tbldanhmuc._iddanhmuc,tbldanhmuc._tendanhmuc,\n"
                + "	   tbldiachi._iddiachi,tbldiachi._tendiachi,tbltinraovat._tinhtrang,tbltinraovat._diachi\n"
                + "from tbltinraovat inner join tblaccount on tbltinraovat._idaccount_fk=tblaccount._idaccount\n"
                + "                  inner join tbldanhmuc on tbltinraovat._iddanhmuc_fk=tbldanhmuc._iddanhmuc\n"
                + "				  inner join tbldiachi on tbltinraovat._iddiachi_fk=tbldiachi._iddiachi\n"
                + "				  where getdate()- tbltinraovat._thoigian<30 and tbltinraovat._status='off' ORDER BY tbltinraovat._type desc ,tbltinraovat._thoigian desc";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String idtin = rs.getString(1);
                String nameacc = rs.getString(14);
                String namediachi = rs.getString(18);
                String kieutin = rs.getString(5);
                String tieude = rs.getString(6);
                String img = rs.getString(7);
                String gia = rs.getString(8);
                String thoigian = rs.getString(9);
                String namedanhmuc = rs.getString(16);
                String std = rs.getString(11);
                String mota = rs.getString(12);
                String tinhtrang = rs.getString(19);
                String diachicuthe = rs.getString(20);
                raovat temp = new raovat(idtin, nameacc, namediachi, kieutin, tieude, img, gia, namedanhmuc, thoigian, std, mota, tinhtrang, diachicuthe);
                list.add(temp);
            }
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);

        }
        return list;
    }

    public ArrayList<raovat> update(String id) {
        ArrayList<raovat> list = new ArrayList<raovat>();
        String sql = " UPDATE tbltinraovat SET _status='on' WHERE _idtin='" + id + "'  ";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {

            }
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);

        }
        return list;
    }

    public ArrayList<raovat> getListaccount(String idacc) {
        ArrayList<raovat> list = new ArrayList<raovat>();
        String sql = "select tbltinraovat._idtin,tbltinraovat._iddanhmuc_fk,tbltinraovat._iddiachi_fk,tbltinraovat._idaccount_fk,tbltinraovat._kieutin,tbltinraovat._tieude,tbltinraovat._img,\n"
                + "       tbltinraovat._gia,tbltinraovat._thoigian,tbltinraovat._type,tbltinraovat._std,tbltinraovat._mota,\n"
                + "	   tblaccount._idaccount,tblaccount._hoten,\n"
                + "	   tbldanhmuc._iddanhmuc,tbldanhmuc._tendanhmuc,\n"
                + "	   tbldiachi._iddiachi,tbldiachi._tendiachi,tbltinraovat._tinhtrang,tbltinraovat._diachi\n"
                + "from tbltinraovat inner join tblaccount on tbltinraovat._idaccount_fk=tblaccount._idaccount\n"
                + "                  inner join tbldanhmuc on tbltinraovat._iddanhmuc_fk=tbldanhmuc._iddanhmuc\n"
                + "				  inner join tbldiachi on tbltinraovat._iddiachi_fk=tbldiachi._iddiachi\n"
                + "				  where getdate()- tbltinraovat._thoigian<30 and tbltinraovat._status='on' AND tblaccount._idaccount='" + idacc + "' ORDER BY tbltinraovat._type desc ,tbltinraovat._thoigian desc";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String idtin = rs.getString(1);
                String nameacc = rs.getString(14);
                String namediachi = rs.getString(18);
                String kieutin = rs.getString(5);
                String tieude = rs.getString(6);
                String img = rs.getString(7);
                String gia = rs.getString(8);
                String thoigian = rs.getString(9);
                String namedanhmuc = rs.getString(16);
                String std = rs.getString(11);
                String mota = rs.getString(12);
                String tinhtrang = rs.getString(19);
                String diachicuthe = rs.getString(20);
                raovat temp = new raovat(idtin, nameacc, namediachi, kieutin, tieude, img, gia, namedanhmuc, thoigian, std, mota, tinhtrang, diachicuthe);
                list.add(temp);
            }
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);

        }
        return list;
    }

    public boolean updateacc(String idacc, int amount,int songay) {
        PreparedStatement prst = null;
        String sql1 = "UPDATE tblAccount SET _sotine=_sotine-?,_type='vip',_ngaygiahan=getdate(),_ngayhethan=getdate()+? WHERE _idaccount=?";

        try {
            prst = getConnection().prepareStatement(sql1);
            prst.setString(3, idacc);
            prst.setInt(1, amount);
            prst.setInt(2, songay);
            prst.executeUpdate();
            prst.close();
        } catch (Exception ex) {
            return false;
        }
        return true;
    }

    public ArrayList<raovat> getbyId(String idt) {
        ArrayList<raovat> list = new ArrayList<raovat>();
        String sql = "select tbltinraovat._idtin,tbltinraovat._iddanhmuc_fk,tbltinraovat._iddiachi_fk,tbltinraovat._idaccount_fk,tbltinraovat._kieutin,tbltinraovat._tieude,tbltinraovat._img,\n"
                + "       tbltinraovat._gia,tbltinraovat._thoigian,tbltinraovat._type,tbltinraovat._std,tbltinraovat._mota,\n"
                + "	   tblaccount._idaccount,tblaccount._hoten,\n"
                + "	   tbldanhmuc._iddanhmuc,tbldanhmuc._tendanhmuc,\n"
                + "	   tbldiachi._iddiachi,tbldiachi._tendiachi,tbltinraovat._tinhtrang,tbltinraovat._diachi\n"
                + "from tbltinraovat inner join tblaccount on tbltinraovat._idaccount_fk=tblaccount._idaccount\n"
                + "                  inner join tbldanhmuc on tbltinraovat._iddanhmuc_fk=tbldanhmuc._iddanhmuc\n"
                + "				  inner join tbldiachi on tbltinraovat._iddiachi_fk=tbldiachi._iddiachi\n"
                + "				  where getdate()- tbltinraovat._thoigian<30 and tbltinraovat._status='on' AND tbltinraovat._idtin='" + idt + "' ORDER BY tbltinraovat._type desc ,tbltinraovat._thoigian desc";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String idtin = rs.getString(1);
                String nameacc = rs.getString(14);
                String namediachi = rs.getString(18);
                String kieutin = rs.getString(5);
                String tieude = rs.getString(6);
                String img = rs.getString(7);
                String gia = rs.getString(8);
                String thoigian = rs.getString(9);
                String namedanhmuc = rs.getString(16);
                String std = rs.getString(11);
                String mota = rs.getString(12);
                String tinhtrang = rs.getString(19);
                String diachicuthe = rs.getString(20);
                raovat temp = new raovat(idtin, nameacc, namediachi, kieutin, tieude, img, gia, namedanhmuc, thoigian, std, mota, tinhtrang, diachicuthe);
                list.add(temp);
            }
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);

        }
        return list;
    }

    public ArrayList<raovat> getdataPrice1() {
        ArrayList<raovat> list = new ArrayList<raovat>();
        String sql = "select tbltinraovat._idtin,tbltinraovat._iddanhmuc_fk,tbltinraovat._iddiachi_fk,tbltinraovat._idaccount_fk,tbltinraovat._kieutin,tbltinraovat._tieude,tbltinraovat._img,\n"
                + "       tbltinraovat._gia,tbltinraovat._thoigian,tbltinraovat._type,tbltinraovat._std,tbltinraovat._mota,\n"
                + "	   tblaccount._idaccount,tblaccount._hoten,\n"
                + "	   tbldanhmuc._iddanhmuc,tbldanhmuc._tendanhmuc,\n"
                + "	   tbldiachi._iddiachi,tbldiachi._tendiachi,tbltinraovat._tinhtrang,tbltinraovat._diachi\n"
                + "from tbltinraovat inner join tblaccount on tbltinraovat._idaccount_fk=tblaccount._idaccount\n"
                + "                  inner join tbldanhmuc on tbltinraovat._iddanhmuc_fk=tbldanhmuc._iddanhmuc\n"
                + "				  inner join tbldiachi on tbltinraovat._iddiachi_fk=tbldiachi._iddiachi\n"
                + "				  where getdate()- tbltinraovat._thoigian<30 and tbltinraovat._status='on'  ORDER BY  CAST(tbltinraovat._gia AS int) asc";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String idtin = rs.getString(1);
                String nameacc = rs.getString(14);
                String namediachi = rs.getString(18);
                String kieutin = rs.getString(5);
                String tieude = rs.getString(6);
                String img = rs.getString(7);
                String gia = rs.getString(8);
                String thoigian = rs.getString(9);
                String namedanhmuc = rs.getString(16);
                String std = rs.getString(11);
                String mota = rs.getString(12);
                String tinhtrang = rs.getString(19);
                String diachicuthe = rs.getString(20);
                raovat temp = new raovat(idtin, nameacc, namediachi, kieutin, tieude, img, gia, namedanhmuc, thoigian, std, mota, tinhtrang, diachicuthe);
                list.add(temp);
            }
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);

        }
        return list;
    }

    public ArrayList<raovat> getdataPrice2() {
        ArrayList<raovat> list = new ArrayList<raovat>();
        String sql = "select tbltinraovat._idtin,tbltinraovat._iddanhmuc_fk,tbltinraovat._iddiachi_fk,tbltinraovat._idaccount_fk,tbltinraovat._kieutin,tbltinraovat._tieude,tbltinraovat._img,\n"
                + "       tbltinraovat._gia,tbltinraovat._thoigian,tbltinraovat._type,tbltinraovat._std,tbltinraovat._mota,\n"
                + "	   tblaccount._idaccount,tblaccount._hoten,\n"
                + "	   tbldanhmuc._iddanhmuc,tbldanhmuc._tendanhmuc,\n"
                + "	   tbldiachi._iddiachi,tbldiachi._tendiachi,tbltinraovat._tinhtrang,tbltinraovat._diachi\n"
                + "from tbltinraovat inner join tblaccount on tbltinraovat._idaccount_fk=tblaccount._idaccount\n"
                + "                  inner join tbldanhmuc on tbltinraovat._iddanhmuc_fk=tbldanhmuc._iddanhmuc\n"
                + "				  inner join tbldiachi on tbltinraovat._iddiachi_fk=tbldiachi._iddiachi\n"
                + "				  where getdate()- tbltinraovat._thoigian<30 and tbltinraovat._status='on'  ORDER BY  CAST(tbltinraovat._gia AS int) desc";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String idtin = rs.getString(1);
                String nameacc = rs.getString(14);
                String namediachi = rs.getString(18);
                String kieutin = rs.getString(5);
                String tieude = rs.getString(6);
                String img = rs.getString(7);
                String gia = rs.getString(8);
                String thoigian = rs.getString(9);
                String namedanhmuc = rs.getString(16);
                String std = rs.getString(11);
                String mota = rs.getString(12);
                String tinhtrang = rs.getString(19);
                String diachicuthe = rs.getString(20);
                raovat temp = new raovat(idtin, nameacc, namediachi, kieutin, tieude, img, gia, namedanhmuc, thoigian, std, mota, tinhtrang, diachicuthe);
                list.add(temp);
            }
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);

        }
        return list;
    }

    public ArrayList<raovat> gettinmoi() {
        ArrayList<raovat> list = new ArrayList<raovat>();
        String sql = "select tbltinraovat._idtin,tbltinraovat._iddanhmuc_fk,tbltinraovat._iddiachi_fk,tbltinraovat._idaccount_fk,tbltinraovat._kieutin,tbltinraovat._tieude,tbltinraovat._img,\n"
                + "       tbltinraovat._gia,tbltinraovat._thoigian,tbltinraovat._type,tbltinraovat._std,tbltinraovat._mota,\n"
                + "	   tblaccount._idaccount,tblaccount._hoten,\n"
                + "	   tbldanhmuc._iddanhmuc,tbldanhmuc._tendanhmuc,\n"
                + "	   tbldiachi._iddiachi,tbldiachi._tendiachi,tbltinraovat._tinhtrang,tbltinraovat._diachi \n"
                + "from tbltinraovat inner join tblaccount on tbltinraovat._idaccount_fk=tblaccount._idaccount\n"
                + "                  inner join tbldanhmuc on tbltinraovat._iddanhmuc_fk=tbldanhmuc._iddanhmuc\n"
                + "				  inner join tbldiachi on tbltinraovat._iddiachi_fk=tbldiachi._iddiachi\n"
                + "				  where getdate()- tbltinraovat._thoigian<30 and tbltinraovat._status='on' ORDER BY tbltinraovat._thoigian desc";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String idtin = rs.getString(1);
                String nameacc = rs.getString(14);
                String namediachi = rs.getString(18);
                String kieutin = rs.getString(5);
                String tieude = rs.getString(6);
                String img = rs.getString(7);
                String gia = rs.getString(8);
                String thoigian = rs.getString(9);
                String namedanhmuc = rs.getString(16);
                String std = rs.getString(11);
                String mota = rs.getString(12);
                String tinhtrang = rs.getString(19);
                String diachicuthe = rs.getString(20);
                raovat temp = new raovat(idtin, nameacc, namediachi, kieutin, tieude, img, gia, namedanhmuc, thoigian, std, mota, tinhtrang, diachicuthe);
                list.add(temp);
            }
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);

        }
        return list;
    }

    public ArrayList<raovat> gettincu() {
        ArrayList<raovat> list = new ArrayList<raovat>();
        String sql = "select tbltinraovat._idtin,tbltinraovat._iddanhmuc_fk,tbltinraovat._iddiachi_fk,tbltinraovat._idaccount_fk,tbltinraovat._kieutin,tbltinraovat._tieude,tbltinraovat._img,\n"
                + "       tbltinraovat._gia,tbltinraovat._thoigian,tbltinraovat._type,tbltinraovat._std,tbltinraovat._mota,\n"
                + "	   tblaccount._idaccount,tblaccount._hoten,\n"
                + "	   tbldanhmuc._iddanhmuc,tbldanhmuc._tendanhmuc,\n"
                + "	   tbldiachi._iddiachi,tbldiachi._tendiachi,tbltinraovat._tinhtrang,tbltinraovat._diachi \n"
                + "from tbltinraovat inner join tblaccount on tbltinraovat._idaccount_fk=tblaccount._idaccount\n"
                + "                  inner join tbldanhmuc on tbltinraovat._iddanhmuc_fk=tbldanhmuc._iddanhmuc\n"
                + "				  inner join tbldiachi on tbltinraovat._iddiachi_fk=tbldiachi._iddiachi\n"
                + "				  where getdate()- tbltinraovat._thoigian<30 and tbltinraovat._status='on' ORDER BY tbltinraovat._thoigian asc";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String idtin = rs.getString(1);
                String nameacc = rs.getString(14);
                String namediachi = rs.getString(18);
                String kieutin = rs.getString(5);
                String tieude = rs.getString(6);
                String img = rs.getString(7);
                String gia = rs.getString(8);
                String thoigian = rs.getString(9);
                String namedanhmuc = rs.getString(16);
                String std = rs.getString(11);
                String mota = rs.getString(12);
                String tinhtrang = rs.getString(19);
                String diachicuthe = rs.getString(20);
                raovat temp = new raovat(idtin, nameacc, namediachi, kieutin, tieude, img, gia, namedanhmuc, thoigian, std, mota, tinhtrang, diachicuthe);
                list.add(temp);
            }
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);

        }
        return list;
    }

    public ArrayList<raovat> getmoi() {
        ArrayList<raovat> list = new ArrayList<raovat>();
        String sql = "select tbltinraovat._idtin,tbltinraovat._iddanhmuc_fk,tbltinraovat._iddiachi_fk,tbltinraovat._idaccount_fk,tbltinraovat._kieutin,tbltinraovat._tieude,tbltinraovat._img,\n"
                + "       tbltinraovat._gia,tbltinraovat._thoigian,tbltinraovat._type,tbltinraovat._std,tbltinraovat._mota,\n"
                + "	   tblaccount._idaccount,tblaccount._hoten,\n"
                + "	   tbldanhmuc._iddanhmuc,tbldanhmuc._tendanhmuc,\n"
                + "	   tbldiachi._iddiachi,tbldiachi._tendiachi,tbltinraovat._tinhtrang,tbltinraovat._diachi \n"
                + "from tbltinraovat inner join tblaccount on tbltinraovat._idaccount_fk=tblaccount._idaccount\n"
                + "                  inner join tbldanhmuc on tbltinraovat._iddanhmuc_fk=tbldanhmuc._iddanhmuc\n"
                + "				  inner join tbldiachi on tbltinraovat._iddiachi_fk=tbldiachi._iddiachi\n"
                + "				  where getdate()- tbltinraovat._thoigian<30 and tbltinraovat._status='on' and _tinhtrang=N'Mới' order by _thoigian desc";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String idtin = rs.getString(1);
                String nameacc = rs.getString(14);
                String namediachi = rs.getString(18);
                String kieutin = rs.getString(5);
                String tieude = rs.getString(6);
                String img = rs.getString(7);
                String gia = rs.getString(8);
                String thoigian = rs.getString(9);
                String namedanhmuc = rs.getString(16);
                String std = rs.getString(11);
                String mota = rs.getString(12);
                String tinhtrang = rs.getString(19);
                String diachicuthe = rs.getString(20);
                raovat temp = new raovat(idtin, nameacc, namediachi, kieutin, tieude, img, gia, namedanhmuc, thoigian, std, mota, tinhtrang, diachicuthe);
                list.add(temp);
            }
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);

        }
        return list;
    }

    public ArrayList<raovat> getcu() {
        ArrayList<raovat> list = new ArrayList<raovat>();
        String sql = "select tbltinraovat._idtin,tbltinraovat._iddanhmuc_fk,tbltinraovat._iddiachi_fk,tbltinraovat._idaccount_fk,tbltinraovat._kieutin,tbltinraovat._tieude,tbltinraovat._img,\n"
                + "       tbltinraovat._gia,tbltinraovat._thoigian,tbltinraovat._type,tbltinraovat._std,tbltinraovat._mota,\n"
                + "	   tblaccount._idaccount,tblaccount._hoten,\n"
                + "	   tbldanhmuc._iddanhmuc,tbldanhmuc._tendanhmuc,\n"
                + "	   tbldiachi._iddiachi,tbldiachi._tendiachi,tbltinraovat._tinhtrang,tbltinraovat._diachi \n"
                + "from tbltinraovat inner join tblaccount on tbltinraovat._idaccount_fk=tblaccount._idaccount\n"
                + "                  inner join tbldanhmuc on tbltinraovat._iddanhmuc_fk=tbldanhmuc._iddanhmuc\n"
                + "				  inner join tbldiachi on tbltinraovat._iddiachi_fk=tbldiachi._iddiachi\n"
                + "				  where getdate()- tbltinraovat._thoigian<30 and tbltinraovat._status='on' and _tinhtrang=N'Cũ' order by _thoigian desc";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String idtin = rs.getString(1);
                String nameacc = rs.getString(14);
                String namediachi = rs.getString(18);
                String kieutin = rs.getString(5);
                String tieude = rs.getString(6);
                String img = rs.getString(7);
                String gia = rs.getString(8);
                String thoigian = rs.getString(9);
                String namedanhmuc = rs.getString(16);
                String std = rs.getString(11);
                String mota = rs.getString(12);
                String tinhtrang = rs.getString(19);
                String diachicuthe = rs.getString(20);
                raovat temp = new raovat(idtin, nameacc, namediachi, kieutin, tieude, img, gia, namedanhmuc, thoigian, std, mota, tinhtrang, diachicuthe);
                list.add(temp);
            }
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);

        }
        return list;
    }
    public ArrayList<raovat> Search(String key) {
        ArrayList<raovat> list = new ArrayList<raovat>();
        String sql = "select tbltinraovat._idtin,tbltinraovat._iddanhmuc_fk,tbltinraovat._iddiachi_fk,tbltinraovat._idaccount_fk,tbltinraovat._kieutin,tbltinraovat._tieude,tbltinraovat._img,\n" +
"       tbltinraovat._gia,tbltinraovat._thoigian,tbltinraovat._type,tbltinraovat._std,tbltinraovat._mota,\n" +
"	   tblaccount._idaccount,tblaccount._hoten,\n" +
"	   tbldanhmuc._iddanhmuc,tbldanhmuc._tendanhmuc,\n" +
"	   tbldiachi._iddiachi,tbldiachi._tendiachi,tbltinraovat._tinhtrang,tbltinraovat._diachi\n" +
"from tbltinraovat inner join tblaccount on tbltinraovat._idaccount_fk=tblaccount._idaccount\n" +
"                  inner join tbldanhmuc on tbltinraovat._iddanhmuc_fk=tbldanhmuc._iddanhmuc\n" +
"				  inner join tbldiachi on tbltinraovat._iddiachi_fk=tbldiachi._iddiachi\n" +
"				  where getdate()- tbltinraovat._thoigian<30 and tbltinraovat._status='on'  and tbltinraovat._tieude LIKE '%"+key+"%' ORDER BY tbltinraovat._thoigian desc";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String idtin = rs.getString(1);
                String nameacc = rs.getString(14);
                String namediachi = rs.getString(18);
                String kieutin = rs.getString(5);
                String tieude = rs.getString(6);
                String img = rs.getString(7);
                String gia = rs.getString(8);
                String thoigian = rs.getString(9);
                String namedanhmuc = rs.getString(16);
                String std = rs.getString(11);
                String mota = rs.getString(12);
                String tinhtrang = rs.getString(19);
                String diachicuthe = rs.getString(20);
                raovat temp = new raovat(idtin, nameacc, namediachi, kieutin, tieude, img, gia, namedanhmuc, thoigian, std, mota, tinhtrang, diachicuthe);
                list.add(temp);
            }
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataProcess.class.getName()).log(Level.SEVERE, null, ex);

        }
        return list;
    }
}
